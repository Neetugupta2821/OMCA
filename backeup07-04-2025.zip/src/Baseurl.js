export const omca = "http://192.168.1.95:6500/"; // local api
