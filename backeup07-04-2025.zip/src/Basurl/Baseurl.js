// export const baseurl = 'https://sisccltd.com/omca_crm/api/'  //server
// export const image = 'https://sisccltd.com/omca_crm/'  //server


export const baseurl = 'http://192.168.1.40:5201/api/' //local
export const image = 'https://sisccltd.com/omca_crm/'  //local   